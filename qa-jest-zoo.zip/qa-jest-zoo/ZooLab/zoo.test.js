const Animal = require('./animal')

const myZoo = [
    new Animal("Alex", "Lion", ["meat"]),
    new Animal("Marty", "Zebra", ["grass", "leaves", "shrubs", "bark"]),
    new Animal("Melman", "Giraffe", ["leaves", "hay", "carrots"]),
    new Animal("Gloria", "Hippopotamus", ["grass", "reeds", "shoots"]),
]

describe("Zookeeper Feeding Tests", () => {
    
})