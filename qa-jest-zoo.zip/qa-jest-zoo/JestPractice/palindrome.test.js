test("Palindrome Checker", () => {
    
    let pallyCheck = (word) => {
        return word.split("").reverse().join("")
    }

    
})