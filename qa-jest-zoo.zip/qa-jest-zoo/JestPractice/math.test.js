const operations = {
    add: (num1, num2) => {
        return num1 + num2
    },

    subtract: () => {

    },

    multiply: () => {

    },

    divide: () => {

    }
}

describe("Math Tests", () => {
    
    it("Can add", () => {

    })

    it("Can subtract", () => {
        
    })

    it("Can multiply", () => {
        
    })

    it("Can divide", () => {
        
    })
})